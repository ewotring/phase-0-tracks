* form is container tag for the form
    - name
    - action method
* fieldset breaks the form into separate sections
* label gives a title to an input field
* input is the box for the user response
    - type sets the format of the expected input. This could also be a checkbox.
    - name gives a label to the input when the form is submitted
        + When we changed the name, the label changed in the resultant output.
* select is a drop-down list
    - option is each choice in the drop-down list
* button simply displays a button to click.